from setuptools import setup, find_packages

setup(name='test',
      version='0.1',
      description='testo',
      long_description='testo.',
      classifiers=[

      ],
      keywords='test',
      author='Me',
      author_email='ex@example.com',
      license='MIT',
      packages=find_packages(),
      install_requires=[
      ],
      include_package_data=True,
      zip_safe=False)
